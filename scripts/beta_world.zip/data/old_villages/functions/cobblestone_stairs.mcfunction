execute if block ~ ~ ~ command_block[facing=north] run say north
execute if block ~ ~ ~ command_block[facing=north] run setblock ~ ~-3 ~-1 minecraft:cobblestone_stairs[facing=south,half=bottom,shape=straight]
execute if block ~ ~ ~ command_block[facing=east] run say east
execute if block ~ ~ ~ command_block[facing=east] run setblock ~1 ~-3 ~ minecraft:cobblestone_stairs[facing=west,half=bottom,shape=straight]
execute if block ~ ~ ~ command_block[facing=south] run say south
execute if block ~ ~ ~ command_block[facing=south] run setblock ~ ~-3 ~1 minecraft:cobblestone_stairs[facing=north,half=bottom,shape=straight]
execute if block ~ ~ ~ command_block[facing=west] run say west
execute if block ~ ~ ~ command_block[facing=west] run setblock ~-1 ~-3 ~ minecraft:cobblestone_stairs[facing=east,half=bottom,shape=straight]